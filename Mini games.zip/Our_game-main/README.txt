README

Dataset Title: PlayVerse
Authors: Hasnaat Tanveer, Talha Azhar, Shaan Nabi, Muhid Shafqat
Date of README Files Creation: March 23, 2025
Date of Mast Modified: March 23, 2025

Before running the codes of our game 'PlayVerse' you must have the following softwares installed on your computer:

	- Raylib Library
	- Microsoft Visual Studio Code